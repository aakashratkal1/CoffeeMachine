package com.machinecoding.coffee.enums;

/**
 * Different beverages that can be created.
 */
 public enum Beverage {
    HOT_TEA, HOT_COFFEE, BLACK_TEA, GREEN_TEA
  }
